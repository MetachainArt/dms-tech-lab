// 지식사전 점검: 목록 불일치, 머리 정보 누락, 깨진 연결, 다시 확인할 날 지남, 원본 처리 대기
// 사용: node scripts/check.mjs  (저장고 폴더에서 실행. 다른 폴더면 경로를 붙입니다)
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = process.argv[2] || path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const wikiDir = path.join(root, '20_위키');
const rawDir = path.join(root, '10_원본');
const REQUIRED = ['title', 'type', 'status', 'sources', 'checked', 'tags', 'created', 'updated'];
const TYPES = ['자료요약', '개념', '도구', '실전-방법', '실전-실험', '실전-교훈', '실전-판단', '종합'];
const STATUS = ['직접확인', '출처확인', '작성자주장', '미검증', '폐기'];

function walk(dir) {
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap((d) => {
    if (d.name.startsWith('.')) return [];
    const p = path.join(dir, d.name);
    return d.isDirectory() ? walk(p) : p.endsWith('.md') ? [p] : [];
  });
}
function frontmatter(text) {
  const m = text.match(/^---\r?\n([\s\S]*?)\r?\n---/);
  if (!m) return null;
  const out = {};
  for (const line of m[1].split(/\r?\n/)) {
    const k = line.match(/^([A-Za-z_]+):\s*(.*)$/);
    if (k) out[k[1]] = k[2].trim().replace(/^"|"$/g, '');
  }
  return out;
}

const allNotes = walk(root);
const names = new Set(allNotes.map((p) => path.basename(p, '.md')));
const wikiPages = walk(wikiDir).filter((p) => !['index.md', 'log.md'].includes(path.basename(p)));
const indexText = fs.existsSync(path.join(wikiDir, 'index.md')) ? fs.readFileSync(path.join(wikiDir, 'index.md'), 'utf8') : '';
const today = new Date().toLocaleDateString('sv-SE', { timeZone: 'Asia/Seoul' });
const problems = { 목록누락: [], 목록에만있음: [], 머리정보: [], 깨진연결: [], 재확인지남: [], 원본대기: [] };

for (const p of wikiPages) {
  const name = path.basename(p, '.md');
  const text = fs.readFileSync(p, 'utf8');
  if (!indexText.includes(`[[${name}`)) problems.목록누락.push(name);
  const fm = frontmatter(text);
  if (!fm) problems.머리정보.push(`${name}: 머리 정보 없음`);
  else {
    const miss = REQUIRED.filter((k) => !(k in fm) || fm[k] === '');
    if (miss.length) problems.머리정보.push(`${name}: 빠짐 ${miss.join(', ')}`);
    if (fm.type && !TYPES.includes(fm.type)) problems.머리정보.push(`${name}: type 값 확인(${fm.type})`);
    if (fm.status && !STATUS.includes(fm.status)) problems.머리정보.push(`${name}: status 값 확인(${fm.status})`);
    if (fm.recheck && /^\d{4}-\d{2}-\d{2}$/.test(fm.recheck) && fm.recheck < today && fm.status !== '폐기') problems.재확인지남.push(`${name} (${fm.recheck})`);
  }
  const body = text.replace(/```[\s\S]*?```/g, '');
  for (const m of body.matchAll(/\[\[([^\]|#]+)/g)) {
    const target = m[1].trim();
    if (!names.has(target)) problems.깨진연결.push(`${name} -> ${target}`);
  }
}
for (const m of indexText.matchAll(/\[\[([^\]|#]+)/g)) {
  const t = m[1].trim();
  if (!wikiPages.some((p) => path.basename(p, '.md') === t)) problems.목록에만있음.push(t);
}
for (const p of walk(rawDir)) {
  const fm = frontmatter(fs.readFileSync(p, 'utf8'));
  if (fm && fm.ingest_status && fm.ingest_status !== '완료') problems.원본대기.push(path.basename(p, '.md'));
}

const countLine = indexText.match(/현재 문서 수:\s*(\d+)/);
const countNote = countLine && Number(countLine[1]) !== wikiPages.length ? `목록의 문서 수(${countLine[1]})와 실제(${wikiPages.length})가 다름` : null;

console.log(`위키 문서 ${wikiPages.length}개 점검 (${today})`);
if (countNote) console.log(`- ${countNote}`);
let total = countNote ? 1 : 0;
for (const [k, v] of Object.entries(problems)) {
  if (!v.length) continue;
  total += v.length;
  console.log(`\n[${k}] ${v.length}개`);
  for (const x of v) console.log(`- ${x}`);
}
console.log(total ? `\n문제 ${total}건` : '\n문제 없음');
process.exitCode = total ? 1 : 0;
