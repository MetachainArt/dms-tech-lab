# 리도의 세계수 · 빈 지식사전 서식

AI와 함께 쓰는 개인 지식사전(LLM Wiki) 시작 서식입니다. 옵시디언(Obsidian)으로 열고, Claude Code·Codex·Aside 같은 AI에게 정리를 맡깁니다.
만든 곳: DMS.Labs · 리도 (https://www.dmssolution.co.kr)

## 들어 있는 것
- 폴더 구조: 받은자료 → 원본 → 위키 → 결과물
- `운영규칙.md`: AI가 매번 먼저 읽는 규칙 (출처·확인 상태 표시, 한 곳에서만 수정, 넣지 않을 것)
- `CLAUDE.md` / `AGENTS.md`: Claude Code와 Codex가 자동으로 읽는 안내
- `80_서식`: 원본·자료요약·실전 문서 서식
- `scripts/check.mjs`: 목록 누락, 빠진 정보, 깨진 연결, 다시 확인할 날을 찾는 점검 도구 (Node.js 필요)
- 예시 문서 2개: `20_위키/개념/LLM Wiki.md`, `20_위키/실전/저장됨과 실제 성공은 다르다.md`

## 시작하기
1. 이 폴더를 원하는 곳에 풀고 옵시디언에서 **폴더를 보관소로 열기**를 누릅니다.
2. AI 도구를 이 폴더에서 실행합니다. (예: 이 폴더에서 `claude` 실행)
3. "이 링크를 지식사전에 넣어줘"라고 링크를 주면 AI가 원본 저장 → 요약 → 연결 → 목록·기록 순서로 정리합니다.
4. 질문할 때는 "지식사전에서 ○○ 찾아줘"라고 합니다.
5. 한 달에 한 번 `node scripts/check.mjs`로 점검합니다.

## 권장
- 이 폴더를 git 저장소로 만들어 변경 기록을 남기면, AI가 잘못 고쳐도 되돌릴 수 있습니다.
- 개인정보, 비밀번호, 다른 사람의 대화 원문은 넣지 마세요.

개인 학습과 업무에 맞게 자유롭게 고쳐 쓰셔도 됩니다.

---

# Reedo's World Tree · Empty Knowledge Base Starter

A starter vault for a personal knowledge base maintained with AI (the "LLM Wiki" pattern). Open it in Obsidian and let an AI agent (Claude Code, Codex, Aside) do the filing.
Includes the folder layout, a rules file the AI reads first (`운영규칙.md`), `CLAUDE.md`/`AGENTS.md`, note templates, a Node.js health-check script (`scripts/check.mjs`) and two example notes. Folder and file names are in Korean; rename them freely and update the rules file to match.